Software Responsibilities:

Plant API (https://perenual.com/docs/api) - will supply plant data and will be called from Javascript

Intellij / REST API / Java: models, controllers, services, JdbcTemplates for schema tables  

MySQL - will store plant data that are added to plots that will display to the user

AWS - RDS will connect MySQL database to online server, Elastic Beanstalk will deploy our jar file (jar file is a packaged file of our java classes. DO THIS AT THE END)
React - will cover front end ui and call Plant API URLs 


<img width="910" alt="image" src="https://user-images.githubusercontent.com/122813354/228336176-568f705b-5805-4104-b3b3-87f75c59cae0.png">
