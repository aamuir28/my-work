package learn.communitygarden.domain;

public class PlotServiceTest {
}

//delete