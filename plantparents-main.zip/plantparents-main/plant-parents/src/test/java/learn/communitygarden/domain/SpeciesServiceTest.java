package learn.communitygarden.domain;

public class SpeciesServiceTest {
}

//delete