package learn.communitygarden.domain;

public enum ActionStatus {
    SUCCESS,
    INVALID,
    DUPLICATE,
    NOT_FOUND
}
