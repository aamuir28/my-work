function Heading({children}) {
    return (
      <h2 className="sectionHeader">{children}</h2>
    );
  }
  
  export default Heading;