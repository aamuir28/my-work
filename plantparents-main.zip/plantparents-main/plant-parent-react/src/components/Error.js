function Error() {
    return <p> Error </p>;
  }
  
  export default Error;