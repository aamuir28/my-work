export default function Unauthorized() {
    return (
        <>
            <h2>Unauthorized</h2>
            <section>
                <img src="https://httpstatusdogs.com/img/401.jpg" alt="401 Unauthorized!" />
            </section>
        </>
    )
}