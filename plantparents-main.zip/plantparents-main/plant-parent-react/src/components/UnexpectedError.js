import Heading from './Heading';

function UnexpectedError() {
  return (
    <section>
     <Heading>Unexpected Error</Heading> 
    </section>
    
  );
}

export default UnexpectedError;