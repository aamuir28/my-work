package learn.starwars.domain;

public enum ActionStatus {
    SUCCESS,
    INVALID,
    DUPLICATE,
    NOT_FOUND
}
