// const Search = () => {
//   return (
//     <div class="searchbar row">
//       <div className="searchBox" id='search-box-container'>
//         <input type="search" class="searchField" id="gsearch" name="gsearch" />
//         <button className="btn 3">
//         <i class="fa fa-search" aria-hidden="true"></i>
//         </button>
//         <h3 className="response" id='response'></h3>
//       </div>
//     </div>
//   );
// };

// export default Search;
