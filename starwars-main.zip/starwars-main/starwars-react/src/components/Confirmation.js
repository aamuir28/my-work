function Confirmation() {
  return <p>✅</p>;
}

export default Confirmation;
